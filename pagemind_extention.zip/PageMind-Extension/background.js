// background.js – service worker
// Opens the side panel when the toolbar icon is clicked

chrome.sidePanel
  .setPanelBehavior({ openPanelOnActionClick: true })
  .catch(console.error);

// Listen for messages from the side panel (e.g., "get page content")
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GET_PAGE_CONTENT") {
    // Inject content script into the active tab and ask for page text
    chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
      if (!tabs[0]) {
        sendResponse({ error: "No active tab found." });
        return;
      }
      try {
        const results = await chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: extractPageContent,
        });
        const content = results[0]?.result || "";
        sendResponse({ content, title: tabs[0].title, url: tabs[0].url });
      } catch (err) {
        sendResponse({ error: err.message });
      }
    });
    return true; // keep channel open for async response
  }
});

// This function runs inside the target page context
function extractPageContent() {
  // Remove script/style/nav/footer/header noise
  const clone = document.body.cloneNode(true);
  const remove = clone.querySelectorAll(
    "script, style, noscript, iframe, svg, canvas, header, footer, nav, aside, [aria-hidden='true']"
  );
  remove.forEach((el) => el.remove());

  // Get readable text
  let text = clone.innerText || clone.textContent || "";

  // Collapse excessive whitespace
  text = text.replace(/\n{3,}/g, "\n\n").replace(/[ \t]{2,}/g, " ").trim();

  // Cap at ~15000 characters to keep within API limits
  if (text.length > 15000) {
    text = text.substring(0, 15000) + "\n\n[... content truncated for length ...]";
  }
  return text;
}
