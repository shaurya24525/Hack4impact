// sidepanel.js – all UI logic for the side panel

// ─── DOM refs ───────────────────────────────────────────────────────────────
const btnSummarize    = document.getElementById("btn-summarize");
const summaryOutput   = document.getElementById("summary-output");
const summaryText     = document.getElementById("summary-text");
const btnCopySummary  = document.getElementById("btn-copy-summary");
const chatMessages    = document.getElementById("chat-messages");
const chatInput       = document.getElementById("chat-input");
const btnSend         = document.getElementById("btn-send");
const btnClearChat    = document.getElementById("btn-clear-chat");
const btnSettings     = document.getElementById("btn-settings");
const linkSettings    = document.getElementById("link-settings");
const noKeyBanner     = document.getElementById("no-key-banner");
const loadingOverlay  = document.getElementById("loading-overlay");
const loadingText     = document.getElementById("loading-text");
const pageTitle       = document.getElementById("page-title");
const pageInfoEl      = document.getElementById("page-info");
const modelBadge      = document.getElementById("model-badge");
const tabSummary      = document.getElementById("tab-summary");
const tabChat         = document.getElementById("tab-chat");
const panelSummary    = document.getElementById("panel-summary");
const panelChat       = document.getElementById("panel-chat");

// ─── State ──────────────────────────────────────────────────────────────────
let pageContent  = "";
let pageSummary  = "";
let chatHistory  = [];

// ─── Hardcoded API Key ───────────────────────────────────────────────────────
const GEMINI_API_KEY = "AIzaSyBdq7qXnODiRWZrDzDZE3Ty5CNGcoaSnFQ" //"AIzaSyCqqwQ-2MRXkaAl_DrNWNJoZGY0uz9CihU"//;

// ─── Init ───────────────────────────────────────────────────────────────────
function init() {
  noKeyBanner.classList.add("hidden");
  btnSettings.style.display = "none";
}
init();

// ─── Tab switching ───────────────────────────────────────────────────────────
function switchTab(tab) {
  if (tab === "summary") {
    tabSummary.classList.add("active");
    tabChat.classList.remove("active");
    panelSummary.classList.remove("hidden");
    panelChat.classList.add("hidden");
  } else {
    tabChat.classList.add("active");
    tabSummary.classList.remove("active");
    panelChat.classList.remove("hidden");
    panelSummary.classList.add("hidden");
  }
}
tabSummary.addEventListener("click", () => switchTab("summary"));
tabChat.addEventListener("click", () => switchTab("chat"));

// ─── Helpers ─────────────────────────────────────────────────────────────────
function showLoading(msg = "Thinking") {
  loadingText.textContent = msg;
  loadingOverlay.classList.remove("hidden");
}
function hideLoading() {
  loadingOverlay.classList.add("hidden");
}

function addMessage(role, text) {
  // Remove empty state on first real message
  const empty = document.getElementById("chat-empty");
  if (empty) empty.remove();

  // Remove typing indicator
  const typing = chatMessages.querySelector(".msg-row.typing");
  if (typing) typing.remove();

  const row = document.createElement("div");
  row.className = `msg-row ${role}`;

  if (role === "user") {
    row.innerHTML = `<div class="msg-bubble">${escapeHtml(text)}</div>`;
  } else if (role === "ai") {
    row.innerHTML = `<div class="msg-meta">PageMind</div><div class="msg-bubble">${renderMarkdownish(text)}</div>`;
  } else if (role === "system") {
    row.innerHTML = `<div class="msg-bubble">${escapeHtml(text)}</div>`;
  } else if (role === "error") {
    row.innerHTML = `<div class="msg-bubble">${escapeHtml(text)}</div>`;
  }

  chatMessages.appendChild(row);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return row;
}

function addTypingIndicator() {
  const empty = document.getElementById("chat-empty");
  if (empty) empty.remove();

  const row = document.createElement("div");
  row.className = "msg-row typing ai";
  row.innerHTML = `<div class="msg-bubble"><span></span><span></span><span></span></div>`;

  const bubble = row.querySelector(".msg-bubble"); // ✅ create bubble

  chatMessages.appendChild(row);
  chatMessages.scrollTop = chatMessages.scrollHeight;

  return bubble; // ✅ now it exists
}

function escapeHtml(str) {
  return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

function renderMarkdownish(text) {
  return text
    .split("\n")
    .map(line =>
      `<p>${(line
        .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
        .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
        .replace(/\*(.*?)\*/g, "<em>$1</em>")
        .replace(/`(.*?)`/g, "<code>$1</code>")
      ) || "&nbsp;"}</p>`
    )
    .join("");
}

// ─── Model fallback chain (tried in order) ───────────────────────────────────
const GEMINI_MODELS = [
  "gemini-2.5-flash",
  "gemini-2.0-flash",
  "gemini-2.0-flash-lite",
  "gemini-flash-latest",
  "gemini-flash-lite-latest",
];

// ─── Retry countdown helper ───────────────────────────────────────────────────
function waitWithCountdown(seconds) {
  return new Promise((resolve) => {
    let remaining = Math.ceil(seconds);
    const tick = () => {
      if (remaining <= 0) { resolve(); return; }
      loadingText.textContent = `Rate limited — retrying in ${remaining}s`;
      remaining--;
      setTimeout(tick, 1000);
    };
    tick();
  });
}

// ─── Call a single Gemini model ───────────────────────────────────────────────
async function callModel(model, messages) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
  const body = {
    contents: messages,
    generationConfig: { temperature: 0.7, maxOutputTokens: 1024 },
    safetySettings: [
      { category: "HARM_CATEGORY_HARASSMENT",        threshold: "BLOCK_MEDIUM_AND_ABOVE" },
      { category: "HARM_CATEGORY_HATE_SPEECH",       threshold: "BLOCK_MEDIUM_AND_ABOVE" },
      { category: "HARM_CATEGORY_SEXUALLY_EXPLICIT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
      { category: "HARM_CATEGORY_DANGEROUS_CONTENT", threshold: "BLOCK_MEDIUM_AND_ABOVE" },
    ],
  };
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) {
    const msg = data?.error?.message || `HTTP ${res.status}`;
    // Parse retry delay from error message if present
    const retryMatch = msg.match(/retry in ([\d.]+)s/i);
    const retryAfter = retryMatch ? parseFloat(retryMatch[1]) : null;
    // 429 = rate limit, 404/400 = model not found/unsupported — all should try next model
    const shouldFallback = res.status === 429 || res.status === 404 || res.status === 400;
    throw Object.assign(new Error(msg), { isQuota: shouldFallback, retryAfter });
  }
  const text = data?.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error("Empty response from Gemini.");
  return text.trim();
}

// ─── Call Gemini API — tries all models with auto-retry on quota errors ───────
async function callGemini(messages) {
  let lastError;
  for (const model of GEMINI_MODELS) {
    try {
      // loadingText.textContent = `Calling ${model}`;
      const result = await callModel(model, messages);
      // Show which model responded
      modelBadge.textContent = model.replace("models/","");
      modelBadge.classList.remove("hidden");
      return result;
    } catch (err) {
      lastError = err;
      if (err.isQuota) {
        // If the API told us exactly how long to wait, wait and retry same model once
        if (err.retryAfter) {
          await waitWithCountdown(err.retryAfter + 1);
          try {
            loadingText.textContent = `Retrying ${model}…`;
            return await callModel(model, messages);
          } catch (retryErr) {
            lastError = retryErr;
            // still quota — fall through to next model
          }
        }
        // Try next model
        console.warn(`Model ${model} quota exceeded, trying next…`);
        continue;
      }
      // Non-quota error (bad key, network, etc.) — don't try other models
      throw new Error(`Gemini API error: ${err.message}`);
    }
  }
  throw new Error(`All models are rate-limited or unavailable. Please wait ~1 minute and try again.\n\nLast error: ${lastError?.message}`);
}

// ─── Fetch page content from background ──────────────────────────────────────
function fetchPageContent() {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "GET_PAGE_CONTENT" }, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }
      if (response?.error) {
        reject(new Error(response.error));
        return;
      }
      resolve(response);
    });
  });
}

// ─── Summarize ───────────────────────────────────────────────────────────────
btnSummarize.addEventListener("click", async () => {
  try {
    showLoading("Extracting page content");
    btnSummarize.disabled = true;

    const response = await fetchPageContent();
    pageContent = response.content || "";

    if (!pageContent || pageContent.length < 50) {
      throw new Error("Could not extract meaningful text from this page.");
    }

    if (response.title) {
      pageTitle.textContent = response.title;
      pageInfoEl.classList.remove("hidden");
    }

    loadingText.textContent = "Generating summary";

    const prompt = [
      {
        role: "user",
        parts: [{
          text: `You are a smart reading assistant. Summarize the following webpage content clearly and concisely. Use bullet points for key highlights. Keep it under 300 words.\n\nPage Title: ${response.title}\n\nContent:\n${pageContent}`
        }]
      }
    ];

    const summary = await callGemini(prompt);
    pageSummary = summary;

    summaryText.innerHTML = renderMarkdownish(summary);
    summaryOutput.classList.remove("hidden");

    chatHistory = [];
    addMessage("system", "Page summarized. Switch to Ask AI to ask questions.");

  } catch (err) {
    summaryOutput.classList.remove("hidden");
    summaryText.innerHTML = `<p style="color:var(--danger)">${escapeHtml(err.message)}</p>`;
  } finally {
    hideLoading();
    btnSummarize.disabled = false;
  }
});

// ─── Copy Summary ─────────────────────────────────────────────────────────────
btnCopySummary.addEventListener("click", () => {
  const text = summaryText.innerText || summaryText.textContent;
  navigator.clipboard.writeText(text).then(() => {
    btnCopySummary.classList.add("copied");
    btnCopySummary.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Copied`;
    setTimeout(() => {
      btnCopySummary.classList.remove("copied");
      btnCopySummary.innerHTML = `<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Copy`;
    }, 2000);
  });
});

// ─── Send Chat Message ────────────────────────────────────────────────────────
async function sendMessage() {
  const userText = chatInput.value.trim();
  if (!userText) return;

  chatInput.value = "";
  chatInput.style.height = "auto";
  btnSend.disabled = true;

  addMessage("user", userText);
  addTypingIndicator();

  try {
    // Build context-aware conversation
    // System instruction as first user message (Gemini doesn't have system role in v1beta)
    const systemContext = pageContent
      ? `You are a helpful assistant. The user is reading a webpage. Here is the content of the page:\n\n"""\n${pageContent}\n"""\n\n${pageSummary ? `Summary: ${pageSummary}\n\n` : ""}Answer the user's questions based on this content. If the answer is not in the content, say so honestly.`
      : "You are a helpful assistant. The user hasn't loaded a page yet. Ask them to click 'Summarize Page' first.";

    // Build messages array: system context + history + new user message
    const messages = [];

    if (chatHistory.length === 0) {
      // First message — include full context
      messages.push({
        role: "user",
        parts: [{ text: systemContext + "\n\nUser question: " + userText }]
      });
    } else {
      // Multi-turn: inject context only at start
      messages.push({
        role: "user",
        parts: [{ text: systemContext }]
      });
      messages.push({
        role: "model",
        parts: [{ text: "Understood. I'm ready to answer questions about this page." }]
      });
      // Add previous turns
      chatHistory.forEach((turn) => messages.push(turn));
      // Add new user message
      messages.push({
        role: "user",
        parts: [{ text: userText }]
      });
    }

    const aiReply = await callGemini(messages);

    // Update history for next turn
    chatHistory.push({ role: "user",  parts: [{ text: userText }] });
    chatHistory.push({ role: "model", parts: [{ text: aiReply }] });

    // Keep history manageable (last 10 turns = 20 messages)
    if (chatHistory.length > 20) {
      chatHistory = chatHistory.slice(chatHistory.length - 20);
    }

    addMessage("ai", aiReply);

  } catch (err) {
    const typing = chatMessages.querySelector(".msg-row.typing");
    if (typing) typing.remove();
    addMessage("error", err.message);
  } finally {
    btnSend.disabled = false;
    chatInput.focus();
  }
}

// Send on button click
btnSend.addEventListener("click", sendMessage);

// Send on Enter (Shift+Enter for new line)
chatInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

// Auto-resize textarea
chatInput.addEventListener("input", () => {
  chatInput.style.height = "auto";
  chatInput.style.height = Math.min(chatInput.scrollHeight, 120) + "px";
});

// ─── Clear Chat ───────────────────────────────────────────────────────────────
btnClearChat.addEventListener("click", () => {
  chatMessages.innerHTML = "";
  chatHistory = [];
  // Re-add empty state
  chatMessages.innerHTML = `
    <div class="empty-state" id="chat-empty">
      <div class="empty-icon">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      </div>
      <p class="empty-title">Ask about this page</p>
      <p class="empty-body">Summarize the page first, then ask any question about its content.</p>
    </div>`;
});

// ─── Settings ────────────────────────────────────────────────────────────────
btnSettings.addEventListener("click", () => {
  chrome.runtime.openOptionsPage();
});
linkSettings.addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});
