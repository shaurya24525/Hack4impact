# create_icons.ps1
# Run this script once to generate the 3 required icon PNG files.
# Requires: PowerShell 5+ (built-in on Windows 10/11)
# Usage: Right-click > "Run with PowerShell"  OR  powershell -File create_icons.ps1

Add-Type -AssemblyName System.Drawing

function New-Icon {
    param([int]$Size, [string]$OutPath)

    $bmp = New-Object System.Drawing.Bitmap($Size, $Size)
    $g   = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode   = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAliasGridFit

    # Background rounded rect (simulate with filled rectangle for simplicity)
    $bgBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 26, 29, 39))
    $g.FillRectangle($bgBrush, 0, 0, $Size, $Size)

    # Accent circle
    $accentBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(255, 108, 99, 255))
    $circleR = [int]($Size * 0.68)
    $circleX = [int](($Size - $circleR) / 2)
    $circleY = [int](($Size - $circleR) / 2)
    $g.FillEllipse($accentBrush, $circleX, $circleY, $circleR, $circleR)

    # Text "PM"
    $fontSize  = [float]($Size * 0.28)
    $font      = New-Object System.Drawing.Font("Arial", $fontSize, [System.Drawing.FontStyle]::Bold)
    $textBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
    $sf        = New-Object System.Drawing.StringFormat
    $sf.Alignment     = [System.Drawing.StringAlignment]::Center
    $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
    $g.DrawString("PM", $font, $textBrush, [System.Drawing.RectangleF]::new(0, 0, $Size, $Size), $sf)

    $bmp.Save($OutPath, [System.Drawing.Imaging.ImageFormat]::Png)
    $g.Dispose()
    $bmp.Dispose()
    Write-Host "Created: $OutPath"
}

$iconsDir = Join-Path $PSScriptRoot "icons"
if (-not (Test-Path $iconsDir)) { New-Item -ItemType Directory -Path $iconsDir | Out-Null }

New-Icon -Size 16  -OutPath "$iconsDir\icon16.png"
New-Icon -Size 48  -OutPath "$iconsDir\icon48.png"
New-Icon -Size 128 -OutPath "$iconsDir\icon128.png"

Write-Host "`nAll icons created in the icons/ folder." -ForegroundColor Green
