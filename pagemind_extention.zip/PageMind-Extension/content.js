// content.js – injected into every page
// Acts as a lightweight relay so the side panel can request page text
// (The actual extraction happens via scripting.executeScript in background.js,
//  so this file is intentionally minimal.)

// No-op: extraction is handled by background.js via executeScript.
// This file is kept to satisfy the content_scripts declaration.
